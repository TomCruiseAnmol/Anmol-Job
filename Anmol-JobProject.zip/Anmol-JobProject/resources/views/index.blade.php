
<div class="header">
<a href="/">Home</a>
<a href="/pushjob">Add Job</a>
</div>