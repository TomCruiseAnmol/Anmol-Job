<style>
* {
    box-sizing: border-box;
}
a {
    text-decoration: none;
    font-size:2vw;
    color: black;
}
.head{
    margin:20px;
}
.job-link
{
    text-decoration:none;
    color: lightblue;
	font-size: 2vw;
	border: 1px solid lightgray;
	border-radius: 25px;
	padding: 3px;
    margin:8px;
}
</style>

<div class="header">
<a class="head" href="/">Home</a>
<a class="head" href="/pushjob">Add Job</a>
</div>
<br>
<div>
<?php //dd($jobs) ?>
<h3><strong>Opening Jobs:</strong></h3>
    @foreach($jobs as $job) 
        <form action="{{('showdetails')}}">
        
        <div>
            <h1>Job Name: {{$job->job_name}}<h1>
            <h3>Minimum Experience: {{$job->min_ex}}years<h3>
            <h3>Maximum Experience: {{$job->max_ex}}years<h3>
            <h3>Total Vacancies: {{$job->job_opening}}<h3>
            <h3>CTC: {{$job->ctc}}lpa<h3>
            <h3>Interview Process: {{$job->interview_process}}<h3>
            <input type="text" name="job_id" value="{{$job->id}}" hidden="">
            <button>Apply For This Job</button
        </div>
        </form> 
        
    @endforeach
</div>