@if($errors->any())
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            @foreach($errors->all() as $error)
                <li> {{$error}} </li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ ('addJob') }}" method="POST">
    @csrf
    
	<strong>
		Job Name: 
	</strong>
	<input type="text" name="job_name" placeholder="what profile of job"><br>
    <strong>
		Minimum Experience:
	</strong>
	<input type="text" name="min_ex" placeholder="required minimum experience"><br>
    <strong>
		Maximum Experience:
	</strong>
	<input type="text" name="max_ex" placeholder="required maximum experience"><br>
    <strong>
		Number of Post:
	</strong>
	<input type="text" name="job_opening" placeholder="how many vacancies is available"><br>
    <strong>
        CTC:
	</strong>
	<input type="text" name="ctc" placeholder="what is ctc for this profile"><br>
    <strong>
        Interview Process:
	</strong>
	<input type="text" name="interview_process" placeholder="what is process to interview"><br><br>
	<button>Submit</button>
</form>