@if($errors->any())
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            @foreach($errors->all() as $error)
                <li> {{$error}} </li>
            @endforeach
        </ul>
    </div>
@endif

<form action="{{ ('apllyJob') }}" method="POST">
    @csrf
    
	<strong>
		Name: 
	</strong>
	<input type="text" name="user_name" placeholder="Enter your name"><br>
    <strong>
		Email:
	</strong>
	<input type="text" name="email" placeholder="Enter your email id"><br>
    <strong>
		Mobile No:
	</strong>
	<input type="text" name="contact_no" placeholder="Enter your mobile number"><br>
    <strong>
		Current CTC:
	</strong>
	<input type="text" name="current_ctc"><br>
    <strong>
        Expected CTC:
	</strong>
	<input type="text" name="expected_ctc"><br>
	<input type="text" name="job_id" value="{{$jobid}}" hidden=""><br><br>
	<button>Submit</button>
</form>