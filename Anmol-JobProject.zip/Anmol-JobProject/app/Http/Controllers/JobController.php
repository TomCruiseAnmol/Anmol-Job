<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Job;

class JobController extends Controller
{
    //
    public function createJob(REQUEST $request){        
        $request->validate([ 
            'job_name' => 'required',
            'min_ex' => 'required',
            'min_ex' => 'required',
            'job_opening' => 'required',
            'ctc' => 'required',
            'interview_process' => 'required',
        ]);

        Job::create($request->all());
        $jobs = DB::select('select * from jobs');
    return view('welcome',['jobs'=>$jobs])->with('success', 'Job has been created successfully');
    }

    public function showJob(){

        $jobs = DB::select('select * from jobs');
        
        return view('welcome',['jobs'=>$jobs]);
    }
    public function showSingleJob( REQUEST $request){
        $jobid = $request->job_id;
        return view('userform',['jobid'=>$jobid]);

    }
}
