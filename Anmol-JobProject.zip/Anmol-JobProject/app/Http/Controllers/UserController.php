<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\User;

class UserController extends Controller
{
    //
    public function userJob(REQUEST $request){        
        $request->validate([ 
            'user_name' => 'required',
            'email' => 'required',
            'contact_no' => 'required',
            'current_ctc' => 'required',
            'expected_ctc' => 'required',            
        ]);

        User::create($request->all());
    return redirect('/')->with('success', 'you have successfully applied for the job');
    }
}
