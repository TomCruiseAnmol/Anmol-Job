<?php if($errors->any()): ?>
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(('addJob')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
	<strong>
		Job Name: 
	</strong>
	<input type="text" name="job_name" placeholder="what profile of job"><br>
    <strong>
		Minimum Experience:
	</strong>
	<input type="text" name="min_ex" placeholder="required minimum experience"><br>
    <strong>
		Maximum Experience:
	</strong>
	<input type="text" name="max_ex" placeholder="required maximum experience"><br>
    <strong>
		Number of Post:
	</strong>
	<input type="text" name="job_opening" placeholder="how many vacancies is available"><br>
    <strong>
        CTC:
	</strong>
	<input type="text" name="ctc" placeholder="what is ctc for this profile"><br>
    <strong>
        Interview Process:
	</strong>
	<input type="text" name="interview_process" placeholder="what is process to interview"><br><br>
	<button>Submit</button>
</form><?php /**PATH C:\Users\TOM CRUISE\Desktop\laravel\Anmol-JobProject\Anmol-JobProject\resources\views/jobform.blade.php ENDPATH**/ ?>