<?php if($errors->any()): ?>
    <div>
        <strong>There sre some problem with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li> <?php echo e($error); ?> </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(('apllyJob')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    
	<strong>
		Name: 
	</strong>
	<input type="text" name="user_name" placeholder="Enter your name"><br>
    <strong>
		Email:
	</strong>
	<input type="text" name="email" placeholder="Enter your email id"><br>
    <strong>
		Mobile No:
	</strong>
	<input type="text" name="contact_no" placeholder="Enter your mobile number"><br>
    <strong>
		Current CTC:
	</strong>
	<input type="text" name="current_ctc"><br>
    <strong>
        Expected CTC:
	</strong>
	<input type="text" name="expected_ctc"><br>
	<input type="text" name="job_id" value="<?php echo e($jobid); ?>" hidden=""><br><br>
	<button>Submit</button>
</form><?php /**PATH C:\Users\TOM CRUISE\Desktop\laravel\Anmol-JobProject\Anmol-JobProject\resources\views/userform.blade.php ENDPATH**/ ?>