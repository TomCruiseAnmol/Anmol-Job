<style>
* {
    box-sizing: border-box;
}
a {
    text-decoration: none;
    font-size:2vw;
    color: black;
}
.head{
    margin:20px;
}
.job-link
{
    text-decoration:none;
    color: lightblue;
	font-size: 2vw;
	border: 1px solid lightgray;
	border-radius: 25px;
	padding: 3px;
    margin:8px;
}
</style>

<div class="header">
<a class="head" href="/">Home</a>
<a class="head" href="/pushjob">Add Job</a>
</div>
<br>
<div>
<?php //dd($jobs) ?>
<h3><strong>Opening Jobs:</strong></h3>
    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <form action="<?php echo e(('showdetails')); ?>">
        
        <div>
            <h1>Job Name: <?php echo e($job->job_name); ?><h1>
            <h3>Minimum Experience: <?php echo e($job->min_ex); ?>years<h3>
            <h3>Maximum Experience: <?php echo e($job->max_ex); ?>years<h3>
            <h3>Total Vacancies: <?php echo e($job->job_opening); ?><h3>
            <h3>CTC: <?php echo e($job->ctc); ?>lpa<h3>
            <h3>Interview Process: <?php echo e($job->interview_process); ?><h3>
            <input type="text" name="job_id" value="<?php echo e($job->id); ?>" hidden="">
            <button>Apply For This Job</button
        </div>
        </form> 
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\Users\TOM CRUISE\Desktop\laravel\Anmol-JobProject\Anmol-JobProject\resources\views/welcome.blade.php ENDPATH**/ ?>